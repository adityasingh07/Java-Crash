package com.myspring.dao;

import java.util.ArrayList;

import javax.transaction.Transactional;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import com.myspring.model.Employee;;

@Component
public class EmployeeDao {

	@Autowired
	SessionFactory sessionfactory;
	
	@Transactional
	public void saveEmp(Employee emp) {
		
		Session session = sessionfactory.getCurrentSession();
		session.save(emp);	
	}
	
	@Transactional
	public void deleteEmp(String eid) {
		
		Session session  = sessionfactory.getCurrentSession();
		Employee emp=new Employee();
		emp.setEmp_id(eid);
		session.delete(emp);
	}
	
	@Transactional
	public void updateEmp(Employee employee) {
		
		Session session  = sessionfactory.getCurrentSession();
		Employee emp1 = new Employee();
		emp1.setEmp_name(employee.getEmp_name());
		emp1.setJob_title(employee.getJob_title());
		emp1.setManager(employee.getManager());
		emp1.setEmp_id(employee.getEmp_id());
		//book2.setBook_id(book_id);
		session.update(emp1);
		
	}
	@Transactional
	public ArrayList<Employee> getallEmp(){
		Session session  = sessionfactory.getCurrentSession();
		ArrayList<Employee> result= (ArrayList<Employee>)session.createQuery("from Employee").list();
		return result;
		
	}
	@Transactional
	public Employee searchEmp(String empid) {
		Session session  = sessionfactory.getCurrentSession();
		Employee result=(Employee)session.get(Employee.class, empid);
		return result;
	}
	
}
