package com.myspring.employees;

import java.text.DateFormat;
import com.myspring.dao.EmployeeDao;
import com.myspring.model.Employee;

import java.util.Date;
import java.util.Locale;
import java.util.ArrayList;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class HomeController {
	
	@Autowired
	EmployeeDao empDao;
	
	@RequestMapping(value="/")
	public String myMeth()
	{
	return "home";
	}
	
	@RequestMapping(value="/addemp")
	public String saveEmp(Model model,@ModelAttribute Employee emp) {
		
		model.addAttribute("emp",emp);
		empDao.saveEmp(emp);
		
		return "output";
	}
	@RequestMapping(value="/deleteemp")
	public String deleteEmp() {
		return "delete";

	}
	@RequestMapping(value="/deleteemp1")
	public String deleteEmp(Model model, @RequestParam("emp_id") String emp_id ) {
		
		String empid=emp_id;
		empDao.deleteEmp(empid);
	
		return "output";}
	
//}
	@RequestMapping(value="/updateemp")
	public String updateEmp() {
		return "update";
		}

	@RequestMapping(value = "/updateemp1") 
	public String updateEmp(Model model,@ModelAttribute Employee emp) {

		
		empDao.updateEmp(emp);

		return "output"; 
	}
	@RequestMapping(value="/goback")
	public String retback() {
		return "home";
		}

	@RequestMapping(value="/displayemp")
	 public String RetreiveAll(Model model) {
		  ArrayList<Employee> res = empDao.getallEmp();
		  model.addAttribute("displayList", res);
		  return "display";
	  }
	@RequestMapping(value="/searchemp")
	public String searchEmp() {
		return "search";
		}
	@RequestMapping(value="/searchemp1")
	public String aEmp(Model model,@RequestParam("emp_id") String emp_id) {
		Employee b=empDao.searchEmp(emp_id);
		model.addAttribute("rescue", b);
		return "dispsearch";
		}
}
